#include <QCoreApplication>
#include <QTcpSocket>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    printf("client_test_0 is started\n");

    QTcpSocket soc;
    soc.connectToHost("127.0.0.1", 7777);
    if (soc.waitForConnected())
    {
        soc.write("say hello");
        if (soc.waitForReadyRead())
        {
            qDebug() << "message from server" << soc.readAll();
        }
        else
        {
            qDebug() << "cannot read data";
        }
    }
    else
    {
        qDebug() << "cannot connect to host";
    }

    return a.exec();
}
