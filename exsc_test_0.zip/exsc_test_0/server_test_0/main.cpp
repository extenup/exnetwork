#include <stdio.h>  // fgets
#include <string.h> // strcmp
#include "../exnetwork/exsc.h" // подключаем исходники ядра

int g_des; // дескриптор серверного потока

// ловим новое подключение
void exsc_newcon(struct exsc_excon con)
{
    printf("the connection was open  %s\n", con.addr);
}

// подключение закрывается
void exsc_closecon(struct exsc_excon con)
{
    printf("the connection was closed  %s\n", con.addr);
}

// принимаем сообщение от клиента
void exsc_recv(struct exsc_excon con, char *buf, int bufsize)
{
    char msg[512] = { 0 };
    memcpy(msg, buf, bufsize);
    printf("receive message from %s\n%s\n", con.addr, msg);

    if (strcmp(msg, "say hello") == 0)
    {
        strcpy(msg, "hello");
        exsc_send(g_des, &con, msg, strlen(msg));
    }
}

void exsc_ext()
{
}

int main()
{
    printf("server_test_0 is started\n");

    exsc_init(2); // инициализируем ядро с рассчётом на два серверных потока

    // запускаем серверный поток на порту 7777
    // он будет держать неактивные соединения 30 секунд
    // будет обрабатывать входящие сообщения в рамках 10 миллисекунд
    // размер буфера для приёма задаём 1024 байта
    // максимальное колличество подключений ограничиваем до 10000
    g_des = exsc_start(7777, 30, 10, 1024, 10000, exsc_newcon, exsc_closecon, exsc_recv, exsc_ext);

    // тормозим главный поток, чтобы программа не завершилась раньше времени
    // программа завершится когда мы введём команду exit и нажмём клавишу ENTER
    while (1)
    {
        const int cmdmaxlen = 256;
        char cmd[cmdmaxlen];
        fgets(cmd, cmdmaxlen, stdin);
        if (strcmp(cmd, "exit\n") == 0)
        {
            break;
        }
    }
    return 0;
}
